public enum EventDefine
{
    ShowSpellPart,
    CloseSpellPart,
    CloseModifierPart,
    ShowModifierPart
}